# <i><li>𝐋𝐢𝐬𝐭 𝐨𝐟 𝐜𝐨𝐥𝐨𝐫𝐬 𝐭𝐡𝐚𝐭 𝐚𝐫𝐞 𝐬𝐮𝐩𝐩𝐨𝐫𝐭𝐞𝐝</li></i>


name color | name color(2) | name color(3) | name color(4) | 
-----------|---------------|---------------|---------------| 
ResetAll   | Underlined    | Cyan          | blue          | 
Bold       | Blink         | Brown         |
Dim        | Reverse       | Dark_Gray     | 
Hidden     | pink          | Purple        | 

# <i>𝐈𝐧𝐬𝐭𝐚𝐥𝐥𝐚𝐭𝐢𝐨𝐧 𝐇𝐞𝐥𝐩</i>

To install, simply run the steps below.Stay with you ! 

HTTPS : 
    
    git clone https://github.com/AhSiber/ColorRandom.git 

SSH : 

    ssh git@github.com:AhSiber/ColorRandom.git 

GITCLI : 

    gh repo clone AhSiber/ColorRandom 


<h3>Installation steps in Linux and Run :</h3>

    (1) - git clone https://github.com/AhSiber/ColorRandom.git 
    (2) - cd ColorRandom 
    (3) - cd color_random_txt 
    (4) - python3 colorMeakUP.py Hello Ahura 

<b><i>if In your system, Python is not following the steps below:</i></b>


    (0) - sudo su - 
    (1) - apt update 
    (2) - apt install python3 
    (3) - python3 -v 
